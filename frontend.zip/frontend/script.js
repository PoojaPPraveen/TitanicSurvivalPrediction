document.getElementById('predictionForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    
    // Gather form data
    const formData = {
        Pclass: parseInt(document.getElementById('pclass').value, 10),
        Sex: document.getElementById('sex').value,
        Age: parseFloat(document.getElementById('age').value),
        SibSp: parseInt(document.getElementById('sibsp').value, 10),
        Parch: parseInt(document.getElementById('parch').value, 10),
        Fare: parseFloat(document.getElementById('fare').value)
    };

    try {
        // Send a POST request to the Flask API
        const response = await fetch('http://127.0.0.1:5000/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const result = await response.json();
        
        // Display the result
        if (result.error) {
            document.getElementById('result').innerHTML = result.error;
        } else {
            document.getElementById('result').innerHTML = `Survived: ${result.survived === 1 ? 'Yes' : 'No'}`;
        }
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('result').innerHTML = 'An error occurred. Please try again.';
    }
});
