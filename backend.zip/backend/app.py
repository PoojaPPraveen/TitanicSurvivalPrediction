from flask import Flask, request, jsonify
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib
import os
from flask_cors import CORS

app = Flask(__name__)

# Enable CORS
CORS(app)

# Load and preprocess the Titanic dataset
def load_and_preprocess_data():
    df = pd.read_csv('titanic.csv')  # Ensure this file is in the same directory
    df = df[['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Survived']]
    df['Sex'] = df['Sex'].map({'male': 0, 'female': 1})
    df = df.fillna(df.mean())
    return df

# Train the model
def train_model():
    df = load_and_preprocess_data()
    X = df[['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare']]
    y = df['Survived']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
    model = RandomForestClassifier(n_estimators=100, random_state=0)
    model.fit(X_train, y_train)
    
    joblib.dump(model, 'model.pkl')

# Initialize and train model if not already trained
if not os.path.exists('model.pkl'):
    train_model()

model = joblib.load('model.pkl')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        print(f"Received data: {data}")

        # Convert to appropriate types
        data['Pclass'] = int(data['Pclass'])
        data['Age'] = float(data['Age'])
        data['SibSp'] = int(data['SibSp'])
        data['Parch'] = int(data['Parch'])
        data['Fare'] = float(data['Fare'])

        # Create DataFrame
        df = pd.DataFrame([data])
        df['Sex'] = df['Sex'].map({'male': 0, 'female': 1})
        df = df.fillna(df.mean())
        print(f"Preprocessed data: {df}")

        X = df[['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare']]
        prediction = model.predict(X)
        print(f"Prediction: {prediction[0]}")

        return jsonify({'survived': int(prediction[0])})
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': 'An error occurred. Please try again.'}), 500

if __name__ == '__main__':
    app.run(debug=True)
